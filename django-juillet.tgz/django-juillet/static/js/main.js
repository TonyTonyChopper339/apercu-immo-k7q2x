// Galerie photo : clic sur une miniature -> change la photo principale
document.addEventListener('click', function (e) {
  var thumb = e.target.closest('.galerie-thumbs .thumb');
  if (thumb) {
    var main = document.getElementById('photo-principale');
    if (main) {
      main.src = thumb.dataset.full || thumb.src;
      document.querySelectorAll('.galerie-thumbs .thumb').forEach(function (t) { t.classList.remove('actif'); });
      thumb.classList.add('actif');
    }
  }
});

// Ferme le menu mobile quand on repasse en grand écran
window.addEventListener('resize', function () {
  if (window.innerWidth > 860) {
    document.body.classList.remove('nav-open');
    var sb = document.getElementById('sidebar');
    if (sb) sb.classList.remove('open');
  }
});
